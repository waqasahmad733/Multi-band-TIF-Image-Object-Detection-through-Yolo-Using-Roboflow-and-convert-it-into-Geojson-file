
Multi-band-TIF-Image-Object-Detection-through-Yolo-Using-Roboflow-and-convert-it-into-Geojson-file
Overview
This Python script provides a comprehensive pipeline for processing multi-band TIF images. The pipeline includes resampling the TIF to a new resolution, splitting the resampled TIF into smaller tiles, running YOLO object detection on these tiles, and finally converting the YOLO detection results into a GeoJSON file. The script is designed to be user-friendly, with a graphical user interface (GUI) built using Tkinter.
Key Features
1. Resampling: Resamples the input TIF to a new spatial resolution (e.g., 3m to 5m) (Note: I make this for my project so if you don��t need to convert resolution keep the same).
2. Tiling: Splits the resampled TIF into smaller tiles (512x512 pixels) and saves them as both TIF and JPG files.
3. YOLO Object Detection: Runs YOLO object detection on each JPG tile and saves the bounding box information in YOLO format (.txt files).
4. GeoJSON Conversion: Converts the YOLO detection results into a single GeoJSON file per TIF subfolder.
Prerequisites
Before running the script, ensure you have the following Python packages installed:
* rasterio
* numpy
* Pillow
* geopandas
* shapely
* roboflow
* tkinter
You can install these packages using pip:
bash
Copy
pip install rasterio numpy Pillow geopandas shapely roboflow
How to Use the Script
1. Run the Script: Execute the script in your Python environment. A GUI window will appear.
2. Select Input Directory: Choose the directory containing the TIF files you want to process.
3. Select Output Directory: Choose the directory where the resampled TIFs, tiles, and YOLO .txt files will be saved.
4. Select GeoJSON Output Directory: Choose the directory where the final GeoJSON files will be saved.
5. Set Parameters: Adjust the parameters such as new resolution, tile size, overlap, brightness, contrast, YOLO confidence, and overlap as needed.
6. Start the Process: Click the "Start" button to begin the processing pipeline.
Detailed Description of the Code
1. Resampling
The?resample_tif_to_new_resolution?function resamples the input TIF to a new spatial resolution using bilinear interpolation. The resampled TIF is saved in the output directory.
2. Tiling
The?split_tif_into_tiles_with_jpg?function splits the resampled TIF into smaller tiles of a specified size (e.g., 512x512 pixels). It also creates JPG versions of these tiles for YOLO processing. The function ensures that only the first three bands (RGB) are kept if the TIF has more than three bands.
3. YOLO Object Detection
The?run_yolo_and_save_txt?function runs YOLO object detection on each JPG tile using the Roboflow API. The detection results are saved in YOLO format (.txt files), which include the class ID, normalized bounding box coordinates, and dimensions.
4. GeoJSON Conversion
The?convert_yolo_txt_to_geojson?function converts the YOLO detection results into a single GeoJSON file. It parses the bounding box information from the .txt files, converts the pixel coordinates to map coordinates, and creates polygons for each detection. These polygons are then saved in a GeoJSON file.
GUI
The?FullPipelineGUI?class provides a graphical user interface for the pipeline. It allows users to select input and output directories, set parameters, and start the processing pipeline. The GUI is built using Tkinter.
Example Usage
1. Input Directory:?/path/to/input/tifs
2. Output Directory:?/path/to/output
3. GeoJSON Output Directory:?/path/to/geojson
4. Parameters:
o New Resolution: 5.0
o Tile Size: 512
o Tile Overlap: 0
o Brightness Factor: 2.0
o Contrast Factor: 2.0
o YOLO Confidence: 40
o YOLO Overlap: 30
o Roboflow API Key:?your_api_key
o Project Name:?your_project_name
o Model Version: 8
After setting the parameters, click "Start" to begin the processing. The script will resample the TIFs, split them into tiles, run YOLO detection, and convert the results into GeoJSON files.

