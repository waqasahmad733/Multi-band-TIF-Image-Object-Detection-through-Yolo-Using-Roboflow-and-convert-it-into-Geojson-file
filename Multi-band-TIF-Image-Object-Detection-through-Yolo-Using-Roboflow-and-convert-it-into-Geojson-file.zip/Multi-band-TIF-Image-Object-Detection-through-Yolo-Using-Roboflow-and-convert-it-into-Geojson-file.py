# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 17:25:57 2025

@author: Admin
"""

# -*- coding: utf-8 -*-
"""
GUI Script:
1) Resample a multi-band TIF (3m -> 5m).
2) Split resampled TIF into 3-band tiles (512x512) + JPG in the same folder.
3) Run YOLO (Roboflow) on each JPG tile -> produce .txt bounding boxes (YOLO format).
4) Now also convert all .txt bounding boxes into a single GeoJSON per TIF subfolder.

Key Updates:
- If the TIF has >=4 bands, we only keep the first 3 (RGBA -> RGB).
- TIF tile, JPG, .txt, and a new .geojson file will go into subfolders.
- We produce .txt for YOLO detections **and** a GeoJSON in a mirrored directory structure.
- We do NOT produce a shapefile anymore.
"""

import os
import time
import tkinter as tk
from tkinter import filedialog, messagebox

import rasterio
from rasterio.enums import Resampling
from rasterio.errors import RasterioIOError
from rasterio.plot import reshape_as_image
import numpy as np

from PIL import Image, ImageEnhance
from roboflow import Roboflow

# Added imports for GeoJSON creation
import geopandas as gpd
from shapely.geometry import Polygon


###############################################################################
# HELPER FUNCTIONS (from your first script)
###############################################################################

def resample_tif_to_new_resolution(input_tif, output_tif, new_resolution):
    """
    Resample the TIF to a new spatial resolution (e.g., 3m -> 5m) using bilinear.
    Returns True if successful, False otherwise.
    """
    try:
        import rasterio
        from rasterio.enums import Resampling

        with rasterio.open(input_tif) as src:
            old_transform = src.transform
            old_res = old_transform[0]  # pixel width (X-res)
            old_width = src.width
            old_height = src.height

            new_width = int(old_width * old_res / new_resolution)
            new_height = int(old_height * old_res / new_resolution)

            new_transform = rasterio.transform.from_origin(
                old_transform.c,  # left
                old_transform.f,  # top
                new_resolution,   # xres
                new_resolution    # yres
            )

            profile = src.profile.copy()
            profile.update({
                "width": new_width,
                "height": new_height,
                "transform": new_transform
            })

            data = src.read(
                out_shape=(src.count, new_height, new_width),
                resampling=Resampling.bilinear
            )

            with rasterio.open(output_tif, 'w', **profile) as dst:
                dst.write(data)

        return True

    except (RasterioIOError, ValueError, TypeError) as e:
        print(f"[WARNING] Could not resample {input_tif}: {e}")
        return False


def adjust_brightness_exposure(image, brightness_factor=2.0, contrast_factor=2.0):
    """
    Adjust brightness and approximate 'exposure' (via contrast) for a PIL image.
    """
    enhancer = ImageEnhance.Brightness(image)
    image = enhancer.enhance(brightness_factor)
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(contrast_factor)
    return image


def split_tif_into_tiles_with_jpg(
    input_tif_path,
    tile_size,
    overlap,
    brightness_factor,
    contrast_factor,
    tile_output_dir
):
    """
    Splits a georeferenced TIF into smaller TIF tiles + JPG copies for YOLO.
    *Forces 3-band if >=4 bands. 
    *Saves TIF + JPG in the same subfolder.

    Returns: list of (tile_tif_path, tile_jpg_path).
    """
    import rasterio
    from rasterio.plot import reshape_as_image

    tile_pairs = []
    base_name = os.path.splitext(os.path.basename(input_tif_path))[0]

    # Create a subfolder for this TIF's tiles
    subdir = os.path.join(tile_output_dir, base_name)
    os.makedirs(subdir, exist_ok=True)

    try:
        with rasterio.open(input_tif_path) as src:
            width, height = src.width, src.height
            profile = src.profile.copy()

            data = src.read()  # shape: (bands, height, width)
            # Force 3-band if more than 3
            if data.shape[0] > 3:
                data = data[:3, :, :]
                profile.update({"count": 3})

            tile_id = 0
            y = 0
            while y < height:
                x = 0
                while x < width:
                    x_end = min(x + tile_size, width)
                    y_end = min(y + tile_size, height)
                    w = x_end - x
                    h = y_end - y

                    window = rasterio.windows.Window.from_slices((y, y_end), (x, x_end))
                    tile_transform = src.window_transform(window)

                    tile_data = data[:, y:y_end, x:x_end]

                    # Update TIF profile
                    tile_profile = profile.copy()
                    tile_profile.update({
                        "width": w,
                        "height": h,
                        "transform": tile_transform
                    })

                    # Save TIF tile
                    tile_tif_name = f"{base_name}_tile_{tile_id}.tif"
                    tile_tif_path = os.path.join(subdir, tile_tif_name)
                    with rasterio.open(tile_tif_path, 'w', **tile_profile) as dst:
                        dst.write(tile_data)

                    # Create JPG tile
                    arr_f32 = tile_data.astype(np.float32)
                    bands_255 = []
                    for b_i in range(arr_f32.shape[0]):
                        band = arr_f32[b_i]
                        band -= band.min()
                        if band.max() > 0:
                            band /= band.max()
                        bands_255.append((band * 255).astype(np.uint8))

                    stacked_255 = np.stack(bands_255, axis=0)
                    img_255 = reshape_as_image(stacked_255)  # (h, w, 3)
                    pil_img = Image.fromarray(img_255)

                    # Adjust brightness/contrast
                    pil_img = adjust_brightness_exposure(
                        pil_img,
                        brightness_factor=brightness_factor,
                        contrast_factor=contrast_factor
                    )

                    tile_jpg_name = f"{base_name}_tile_{tile_id}.jpg"
                    tile_jpg_path = os.path.join(subdir, tile_jpg_name)
                    pil_img.save(tile_jpg_path)

                    tile_pairs.append((tile_tif_path, tile_jpg_path))

                    tile_id += 1
                    x += (tile_size - overlap)
                y += (tile_size - overlap)

    except (RasterioIOError, ValueError, TypeError) as e:
        print(f"[WARNING] Could not split {input_tif_path}: {e}")
        return []

    return tile_pairs


def run_yolo_and_save_txt(
    tile_pairs,
    api_key,
    project_name,
    model_version,
    confidence,
    overlap
):
    """
    Runs YOLO on each JPG tile -> writes .txt bounding boxes (YOLO format).

    YOLO .txt format lines:
      class_id x_center_norm y_center_norm width_norm height_norm

    We assume a single class => class_id = 0 (or parse from pred['class'] if needed).
    """
    if not tile_pairs:
        print(f"[INFO] No tile pairs => skip YOLO TXT creation.")
        return

    rf = Roboflow(api_key=api_key)
    project = rf.workspace().project(project_name)
    model = project.version(model_version).model

    import rasterio

    for tile_tif, tile_jpg in tile_pairs:
        if not os.path.exists(tile_jpg):
            continue

        # Attempt YOLO up to 3 times
        predictions = []
        for attempt in range(3):
            try:
                result = model.predict(tile_jpg, confidence=confidence, overlap=overlap).json()
                predictions = result.get('predictions', [])
                break
            except Exception as e:
                print(f"[ERROR] YOLO on {tile_jpg}, attempt {attempt+1}: {e}")
                time.sleep(5)
        else:
            print(f"[WARNING] Skipping tile after repeated YOLO errors: {tile_jpg}")
            continue

        # Build YOLO .txt
        try:
            with rasterio.open(tile_tif) as src_tile:
                tile_width, tile_height = src_tile.width, src_tile.height

            txt_path = tile_jpg.replace(".jpg", ".txt")
            with open(txt_path, "w") as f:
                for pred in predictions:
                    # If you have multiple classes, parse pred['class'] => numeric ID
                    class_id = 0
                    x_c = pred['x']
                    y_c = pred['y']
                    w = pred['width']
                    h = pred['height']

                    # Normalize
                    x_center_norm = x_c / tile_width
                    y_center_norm = y_c / tile_height
                    w_norm = w / tile_width
                    h_norm = h / tile_height

                    f.write(f"{class_id} {x_center_norm} {y_center_norm} {w_norm} {h_norm}\n")

            print(f"[INFO] {tile_jpg} => {len(predictions)} detections, wrote {txt_path}")

        except Exception as e:
            print(f"[WARNING] Could not write YOLO txt for {tile_jpg}: {e}")


###############################################################################
# ADDITIONAL FUNCTION (from your second script) to convert YOLO .txt to GeoJSON
###############################################################################

# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 15:09:30 2025

@author: Admin
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 15:03:12 2025

@author: Admin
"""

def convert_yolo_txt_to_geojson(tile_dir, output_geojson):
    """
    Recursively find all YOLO .txt files in tile_dir. For each .txt:
      1) Find a matching .tif tile with the same base name.
      2) Parse bounding boxes => polygons in the tile's coordinate system.
    Accumulate in a single list => create one GeoDataFrame => write to GeoJSON.
    """

    detections = []
    accumulated_crs = None

    # Walk the directory for .txt files
    for root, dirs, files in os.walk(tile_dir):
        for fname in files:
            if fname.lower().endswith(".txt"):
                txt_path = os.path.join(root, fname)
                base_name = os.path.splitext(fname)[0]  # e.g. "tile_0"

                # We expect a matching .tif in the same folder
                tif_path = os.path.join(root, base_name + ".tif")
                if not os.path.exists(tif_path):
                    print(f"[WARNING] No matching TIF for {txt_path}, skipping.")
                    continue

                with rasterio.open(tif_path) as src_tile:
                    tile_width = src_tile.width
                    tile_height = src_tile.height
                    tile_transform = src_tile.transform
                    tile_crs = src_tile.crs

                if accumulated_crs is None and tile_crs is not None:
                    accumulated_crs = tile_crs.to_string()

                # Parse YOLO .txt lines
                with open(txt_path, "r") as f:
                    lines = [l.strip() for l in f if l.strip()]

                for line in lines:
                    parts = line.split()
                    if len(parts) != 5:
                        print(f"[WARNING] Skipping malformed line in {txt_path}: {line}")
                        continue

                    class_id_str, xcn_str, ycn_str, wn_str, hn_str = parts
                    try:
                        class_id = class_id_str  # or parse int if needed
                        x_center_norm = float(xcn_str)
                        y_center_norm = float(ycn_str)
                        w_norm = float(wn_str)
                        h_norm = float(hn_str)
                    except ValueError:
                        print(f"[WARNING] Could not parse floats in {txt_path}: {line}")
                        continue

                    # Convert normalized coords -> pixel coords
                    x_center = x_center_norm * tile_width
                    y_center = y_center_norm * tile_height
                    box_w = w_norm * tile_width
                    box_h = h_norm * tile_height

                    # Pixel bounding box corners
                    x_min = x_center - box_w/2
                    x_max = x_center + box_w/2
                    y_min = y_center - box_h/2
                    y_max = y_center + box_h/2

                    # Pixel -> map coords
                    p1 = tile_transform * (x_min, y_min)
                    p2 = tile_transform * (x_min, y_max)
                    p3 = tile_transform * (x_max, y_max)
                    p4 = tile_transform * (x_max, y_min)

                    poly = Polygon([p1, p2, p3, p4])

                    detections.append({
                        "class_id": class_id,
                        "confidence": 1.0,  # or parse from your model if available
                        "geometry": poly
                    })

                print(f"[INFO] Parsed {len(lines)} boxes from {txt_path} => polygons.")

    # Create a GeoDataFrame if we have any detections
    if detections:
        gdf = gpd.GeoDataFrame(detections, crs=accumulated_crs)
        os.makedirs(os.path.dirname(output_geojson), exist_ok=True)
        gdf.to_file(output_geojson, driver="GeoJSON")
        print(f"[DONE] Wrote GeoJSON => {output_geojson}")
    else:
        print("[INFO] No bounding boxes found => No GeoJSON created.")


###############################################################################
# TKINTER GUI (FULL PIPELINE) + GEOJSON EXPORT
###############################################################################

class FullPipelineGUI(tk.Frame):
    """
    1) Select input directory (TIFs).
    2) Select output directory.
    3) Select GeoJSON output directory.
    4) For each TIF:
       - Resample -> keep 3 bands if desired
       - Tile -> TIF + JPG in same subdir
       - YOLO -> produce .txt bounding boxes
       - Convert .txt bounding boxes => single GeoJSON in mirrored subfolder
    """
    def __init__(self, master=None):
        super().__init__(master)
        self.master.title("Resample -> 3-Band Tile -> YOLO -> .txt + GeoJSON")

        # Variables
        self.input_dir_var = tk.StringVar()
        self.output_dir_var = tk.StringVar()
        # New directory for GeoJSON
        self.geojson_dir_var = tk.StringVar()

        self.new_resolution_var = tk.StringVar(value="5.0")
        self.tile_size_var = tk.StringVar(value="512")
        self.overlap_var = tk.StringVar(value="0")

        self.brightness_var = tk.StringVar(value="2.0")
        self.contrast_var = tk.StringVar(value="2.0")

        self.confidence_var = tk.StringVar(value="40")
        self.rf_overlap_var = tk.StringVar(value="30")

        self.api_key_var = tk.StringVar(value="YOUR_API_KEY")
        self.project_name_var = tk.StringVar(value="YOUR_PROJECT_NAME")
        self.model_version_var = tk.StringVar(value="8")

        self.build_gui()

    def build_gui(self):
        row = 0

        # Input directory
        tk.Label(self.master, text="Input Directory (TIFs):").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.input_dir_var, width=40).grid(row=row, column=1, padx=5, pady=5)
        tk.Button(self.master, text="Browse", command=self.select_input_dir).grid(row=row, column=2, padx=5, pady=5)
        row += 1

        # Output directory (for resampled TIF, tiles, YOLO txt)
        tk.Label(self.master, text="Output Directory:").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.output_dir_var, width=40).grid(row=row, column=1, padx=5, pady=5)
        tk.Button(self.master, text="Browse", command=self.select_output_dir).grid(row=row, column=2, padx=5, pady=5)
        row += 1

        # GeoJSON directory
        tk.Label(self.master, text="GeoJSON Output Directory:").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.geojson_dir_var, width=40).grid(row=row, column=1, padx=5, pady=5)
        tk.Button(self.master, text="Browse", command=self.select_geojson_dir).grid(row=row, column=2, padx=5, pady=5)
        row += 1

        # New resolution
        tk.Label(self.master, text="New Resolution (m):").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.new_resolution_var, width=10).grid(row=row, column=1, sticky="w", padx=5, pady=5)
        row += 1

        # Tiling
        tk.Label(self.master, text="Tile Size (px):").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.tile_size_var, width=10).grid(row=row, column=1, sticky="w", padx=5, pady=5)
        row += 1

        tk.Label(self.master, text="Tile Overlap (px):").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.overlap_var, width=10).grid(row=row, column=1, sticky="w", padx=5, pady=5)
        row += 1

        # Brightness/Contrast
        tk.Label(self.master, text="Brightness Factor:").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.brightness_var, width=10).grid(row=row, column=1, sticky="w", padx=5, pady=5)
        row += 1

        tk.Label(self.master, text="Contrast Factor:").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.contrast_var, width=10).grid(row=row, column=1, sticky="w", padx=5, pady=5)
        row += 1

        # YOLO
        tk.Label(self.master, text="YOLO Confidence (0-100):").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.confidence_var, width=10).grid(row=row, column=1, sticky="w", padx=5, pady=5)
        row += 1

        tk.Label(self.master, text="YOLO Overlap (0-100):").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.rf_overlap_var, width=10).grid(row=row, column=1, sticky="w", padx=5, pady=5)
        row += 1

        # Roboflow
        tk.Label(self.master, text="Roboflow API Key:").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.api_key_var, width=25).grid(row=row, column=1, sticky="w", padx=5, pady=5)
        row += 1

        tk.Label(self.master, text="Project Name:").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.project_name_var, width=25).grid(row=row, column=1, sticky="w", padx=5, pady=5)
        row += 1

        tk.Label(self.master, text="Model Version:").grid(row=row, column=0, sticky="e", padx=5, pady=5)
        tk.Entry(self.master, textvariable=self.model_version_var, width=10).grid(row=row, column=1, sticky="w", padx=5, pady=5)
        row += 1

        # Start button
        tk.Button(self.master, text="Start", command=self.start_process, bg="green", fg="white").grid(row=row, column=1, pady=10)

    def select_input_dir(self):
        """Select directory containing TIFs."""
        d = filedialog.askdirectory(title="Select Input Directory (TIFs)")
        if d:
            self.input_dir_var.set(d)

    def select_output_dir(self):
        """Select directory to store resampled TIF, tiles, YOLO .txt."""
        d = filedialog.askdirectory(title="Select Output Directory")
        if d:
            self.output_dir_var.set(d)

    def select_geojson_dir(self):
        """Select directory to store final GeoJSON output."""
        d = filedialog.askdirectory(title="Select GeoJSON Output Directory")
        if d:
            self.geojson_dir_var.set(d)

    def start_process(self):
        """Pipeline: For each TIF -> Resample -> Split(3-band) -> YOLO => .txt => GeoJSON."""
        input_dir = self.input_dir_var.get().strip()
        output_dir = self.output_dir_var.get().strip()
        geojson_dir = self.geojson_dir_var.get().strip()

        if not input_dir or not output_dir or not geojson_dir:
            messagebox.showerror("Error", "Please select Input, Output, and GeoJSON directories.")
            return

        # Parse numeric fields
        try:
            new_res = float(self.new_resolution_var.get())
            tile_size = int(self.tile_size_var.get())
            tile_overlap = int(self.overlap_var.get())
            brightness = float(self.brightness_var.get())
            contrast = float(self.contrast_var.get())
            yolo_conf = int(self.confidence_var.get())
            yolo_overlap = int(self.rf_overlap_var.get())
            model_version = int(self.model_version_var.get())
        except ValueError as e:
            messagebox.showerror("Error", f"Invalid numeric input: {e}")
            return

        # Roboflow
        api_key = self.api_key_var.get().strip()
        project_name = self.project_name_var.get().strip()
        if not api_key or not project_name:
            messagebox.showerror("Error", "Please provide Roboflow API Key and Project Name.")
            return

        # Gather TIF files
        tif_files = []
        for root, dirs, files in os.walk(input_dir):
            for f in files:
                if f.lower().endswith(".tif"):
                    tif_files.append(os.path.join(root, f))

        if not tif_files:
            messagebox.showwarning("No TIFs", "No .tif found in input directory.")
            return

        # Process each TIF
        for tif_path in tif_files:
            print(f"[INFO] Processing TIF => {tif_path}")

            # Mirror the folder structure from input_dir under output_dir
            rel_path = os.path.relpath(os.path.dirname(tif_path), input_dir)
            out_subdir = os.path.join(output_dir, rel_path)
            os.makedirs(out_subdir, exist_ok=True)

            base_name = os.path.splitext(os.path.basename(tif_path))[0]
            resampled_tif = os.path.join(out_subdir, f"{base_name}_resampled.tif")

            # 1) Resample
            ok = resample_tif_to_new_resolution(tif_path, resampled_tif, new_res)
            if not ok:
                continue

            # 2) Split into 3-band TIF tiles + JPG
            tile_pairs = split_tif_into_tiles_with_jpg(
                input_tif_path=resampled_tif,
                tile_size=tile_size,
                overlap=tile_overlap,
                brightness_factor=brightness,
                contrast_factor=contrast,
                tile_output_dir=out_subdir
            )
            if not tile_pairs:
                continue

            # 3) YOLO => .txt
            run_yolo_and_save_txt(
                tile_pairs=tile_pairs,
                api_key=api_key,
                project_name=project_name,
                model_version=model_version,
                confidence=yolo_conf,
                overlap=yolo_overlap
            )

            # 4) Convert all .txt to a single GeoJSON in mirrored subfolder
            geojson_subdir = os.path.join(geojson_dir, rel_path)
            os.makedirs(geojson_subdir, exist_ok=True)
            out_geojson_path = os.path.join(geojson_subdir, f"{base_name}.geojson")

            convert_yolo_txt_to_geojson(
                tile_dir=out_subdir, 
                output_geojson=out_geojson_path
            )

        messagebox.showinfo("Done", f"All TIFs processed! Check outputs in:\n{output_dir}\nand GeoJSON in:\n{geojson_dir}")


def main():
    root = tk.Tk()
    app = FullPipelineGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
